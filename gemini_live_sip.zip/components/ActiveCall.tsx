
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { PhoneContact, Checklist, CallLog } from '../types';
import { encode, decode, decodeAudioData } from '../utils/audio-utils';
import SipClient from '../utils/sip-client';

interface ActiveCallProps {
  contact: PhoneContact;
  checklist: Checklist;
  onFinished: (log: CallLog) => void;
  onClose: () => void;
}

const ActiveCall: React.FC<ActiveCallProps> = ({ contact, checklist, onFinished, onClose }) => {
  const isLocalTest = contact.id === 'local-test';
  const [status, setStatus] = useState<'initiating' | 'ringing' | 'connected' | 'ended'>('initiating');
  const [duration, setDuration] = useState(0);
  const [transcription, setTranscription] = useState<{ speaker: 'agent' | 'user'; text: string }[]>([]);
  const [isMuted, setIsMuted] = useState(false);
  const [isSipMode, setIsSipMode] = useState(false);
  
  const timerRef = useRef<number | null>(null);
  const sessionRef = useRef<any>(null);
  const audioContextInRef = useRef<AudioContext | null>(null);
  const audioContextOutRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Enhanced "Human-Like" System Instruction
  const systemInstruction = `Ты — живой, энергичный и очень эмпатичный администратор. Тебя зовут как одного из сотрудников компании.
Твоя цель: провести естественный, теплый диалог с клиентом по имени ${contact.name}, придерживаясь темы "${checklist.title}".

ПРАВИЛА ОЧЕЛОВЕЧИВАНИЯ (КРИТИЧЕСКИ ВАЖНО):
1. НЕ БУДЬ РОБОТОМ. Не читай вопросы по списку.
2. ИСПОЛЬЗУЙ МЕЖДОМЕТИЯ И ПАУЗЫ. Вставляй в речь: "Так...", "Ммм, понятно", "Ага, хорошо", "Ой, здорово!", "Слушаю вас внимательно".
3. АКТИВНОЕ СЛУШАНИЕ. Прежде чем задать новый вопрос, обязательно отреагируй на предыдущий ответ клиента. Например: "О, пять человек — это отличная компания!", "Понимаю вас, суббота всегда загруженный день".
4. ГОВОРИ ПРОЩЕ. Используй разговорные обороты, но оставайся вежливым. Вместо "Уточните количество персон" скажи "А сколько вас будет человек?".
5. ЭМОЦИИ. Если клиент доволен — радуйся вместе с ним. Если клиент чем-то расстроен — вырази искреннее сожаление.
6. ТЕМП. Не тараторь. Делай логические паузы, как будто ты что-то записываешь в блокнот.

Твои цели на этот разговор:
${checklist.items.map((it, i) => `- ${it}`).join('\n')}

В конце обязательно пожелай хорошего дня так, чтобы клиент улыбнулся.`;

  useEffect(() => {
    // Determine if we should use SIP
    const sipClient = SipClient.getInstance();
    const shouldUseSip = !isLocalTest && sipClient.isConnected();
    setIsSipMode(shouldUseSip);

    if (isLocalTest) {
      const fastConnect = setTimeout(() => {
        handleConnect(false);
      }, 1000);
      return () => {
        clearTimeout(fastConnect);
        stopCall();
      };
    } else {
      const ringTimeout = setTimeout(() => {
        setStatus('ringing');
        const connTimeout = setTimeout(() => {
          handleConnect(shouldUseSip);
        }, 3000);
        return () => clearTimeout(connTimeout);
      }, 2000);

      return () => {
        clearTimeout(ringTimeout);
        stopCall();
      };
    }
  }, []);

  useEffect(() => {
    if (status === 'connected') {
      timerRef.current = window.setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
    return () => { 
      if (timerRef.current) {
        window.clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [status]);

  const handleConnect = async (useSip: boolean) => {
    try {
      setStatus('connected');
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      audioContextInRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextOutRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      let inputStream: MediaStream;
      let sipDestination: MediaStreamAudioDestinationNode | null = null;

      if (useSip) {
        console.log("Starting SIP Call...");
        // Create destination for Gemini Output -> SIP
        sipDestination = audioContextOutRef.current.createMediaStreamDestination();
        
        // Call via SIP
        try {
            const remoteStream = await SipClient.getInstance().call(contact.number, sipDestination.stream);
            inputStream = remoteStream;
            
            // Monitor: Play remote audio locally so admin can hear
            if (audioContextInRef.current) {
                const monitorSource = audioContextInRef.current.createMediaStreamSource(remoteStream);
                monitorSource.connect(audioContextInRef.current.destination);
            }
        } catch (e) {
            console.error("SIP Call Failed", e);
            setStatus('ended');
            return;
        }
      } else {
        console.log("Starting Local Test Call...");
        inputStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      }

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: checklist.voiceName || 'Kore' } },
          },
          systemInstruction,
          outputAudioTranscription: {},
          inputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            if (!audioContextInRef.current) return;
            const source = audioContextInRef.current.createMediaStreamSource(inputStream);
            const scriptProcessor = audioContextInRef.current.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              
              sessionPromise.then(session => {
                if (session && !isMuted && audioContextInRef.current?.state === 'running') {
                  session.sendRealtimeInput({ media: pcmBlob });
                }
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextInRef.current.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && audioContextOutRef.current && audioContextOutRef.current.state !== 'closed') {
              const ctx = audioContextOutRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              
              // Route audio:
              // If SIP: Connect to sipDestination (to remote) AND ctx.destination (monitor)
              // If Local: Connect to ctx.destination (speakers)
              if (useSip && sipDestination) {
                  source.connect(sipDestination);
                  source.connect(ctx.destination); // Monitor
              } else {
                  source.connect(ctx.destination);
              }
              
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            if (message.serverContent?.outputTranscription) {
              const text = message.serverContent.outputTranscription.text;
              setTranscription(prev => [...prev, { speaker: 'agent', text }]);
            } else if (message.serverContent?.inputTranscription) {
              const text = message.serverContent.inputTranscription.text;
              setTranscription(prev => [...prev, { speaker: 'user', text }]);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => {
                try { s.stop(); } catch(e) {}
              });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => console.error('Gemini Live Error:', e),
          onclose: () => console.log('Gemini Live Session Closed'),
        }
      });

      sessionRef.current = await sessionPromise;
      
    } catch (err) {
      console.error("Connection failed", err);
      setStatus('ended');
    }
  };

  const stopCall = () => {
    // Hangup SIP if active
    if (isSipMode) {
        SipClient.getInstance().hangup();
    }

    if (sessionRef.current) {
      try { sessionRef.current.close(); } catch(e) {}
      sessionRef.current = null;
    }
    sourcesRef.current.forEach(s => {
      try { s.stop(); } catch(e) {}
    });
    sourcesRef.current.clear();
    if (audioContextInRef.current && audioContextInRef.current.state !== 'closed') {
      try { audioContextInRef.current.close(); } catch(e) {}
    }
    audioContextInRef.current = null;
    if (audioContextOutRef.current && audioContextOutRef.current.state !== 'closed') {
      try { audioContextOutRef.current.close(); } catch(e) {}
    }
    audioContextOutRef.current = null;
    if (status !== 'ended') {
      setStatus('ended');
      const finalLog: CallLog = {
        id: Date.now().toString(),
        phoneNumber: contact.number,
        customerName: contact.name,
        status: 'completed',
        timestamp: new Date().toISOString(),
        transcript: transcription,
        summary: isLocalTest ? 'Локальное тестирование завершено.' : 'Опрос завершен через SIP-канал.'
      };
      onFinished(finalLog);
    }
  };

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/95 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-white w-full max-w-4xl rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row h-[80vh] border border-white/10">
        
        {/* Call Visualizer Side */}
        <div className={`flex-1 p-8 flex flex-col items-center justify-center text-white relative transition-colors duration-1000 ${
          isLocalTest ? 'bg-gradient-to-b from-slate-700 to-slate-900' : 'bg-gradient-to-b from-indigo-600 to-indigo-900'
        }`}>
          <button 
            onClick={onClose}
            className="absolute top-6 left-6 text-white/50 hover:text-white transition-colors flex items-center gap-2"
          >
            <i className="fas fa-arrow-left"></i> Завершить тест
          </button>

          <div className="absolute top-6 right-6">
            <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
              isLocalTest ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
            }`}>
              <i className={`fas ${isLocalTest ? 'fa-laptop' : 'fa-phone'} mr-1`}></i>
              {isLocalTest ? 'Live Test' : (isSipMode ? 'SIP Call' : 'SIP Simulation')}
            </span>
          </div>

          <div className="relative mb-8">
            <div className={`w-32 h-32 rounded-full border-4 border-white/20 flex items-center justify-center text-4xl bg-white/10 ${
              status === 'connected' ? 'animate-pulse ring-8 ring-white/5' : ''
            }`}>
              <i className={`fas ${isLocalTest ? 'fa-smile-beam' : 'fa-user'}`}></i>
            </div>
            {status === 'connected' && (
              <div className={`absolute -bottom-2 -right-2 w-8 h-8 rounded-full border-4 flex items-center justify-center text-[10px] ${
                isLocalTest ? 'bg-amber-500 border-slate-800' : 'bg-emerald-500 border-indigo-700'
              }`}>
                <i className={`fas ${isLocalTest ? 'fa-microphone' : 'fa-phone'}`}></i>
              </div>
            )}
          </div>

          <h3 className="text-2xl font-bold">{contact.name}</h3>
          <p className="text-white/60 mt-1">{isLocalTest ? 'Режим живой беседы' : contact.number}</p>
          
          <div className="mt-8 text-center min-h-[100px] flex flex-col items-center justify-center">
            {status === 'initiating' && <p className="text-white/60 flex items-center gap-2"><i className="fas fa-spinner animate-spin"></i> Подготовка...</p>}
            {status === 'ringing' && <p className="animate-bounce">Вызываем...</p>}
            {status === 'connected' && (
              <div className="space-y-6">
                <p className="text-emerald-300 font-mono text-3xl tracking-tighter">{formatTime(duration)}</p>
                <div className="flex gap-2 items-end h-16">
                  {[...Array(12)].map((_, i) => (
                    <div 
                      key={i} 
                      className="w-1.5 bg-white/30 rounded-full transition-all duration-150"
                      style={{ 
                        height: `${20 + Math.random() * 80}%`,
                        opacity: 0.3 + Math.random() * 0.7,
                        animation: `pulse ${0.5 + Math.random()}s infinite alternate`
                      }}
                    ></div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="mt-auto pt-8 flex gap-6">
            <button 
              onClick={() => setIsMuted(!isMuted)}
              className={`w-14 h-14 rounded-full flex items-center justify-center text-xl shadow-lg transition-all transform active:scale-95 ${
                isMuted ? 'bg-amber-500 text-white rotate-12' : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
            >
              <i className={`fas ${isMuted ? 'fa-microphone-slash' : 'fa-microphone'}`}></i>
            </button>
            <button 
              onClick={stopCall}
              className="w-16 h-16 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center text-2xl text-white shadow-2xl shadow-red-500/40 transform active:scale-90 transition-all"
            >
              <i className="fas fa-phone-slash"></i>
            </button>
          </div>
        </div>

        {/* Real-time Intel Side */}
        <div className="w-full md:w-[400px] flex flex-col bg-slate-50">
          <div className="p-6 border-b border-slate-200 bg-white">
            <div className="flex items-center justify-between mb-1">
              <h4 className="font-bold text-slate-800 flex items-center gap-2 text-sm">
                <i className="fas fa-tasks text-indigo-500"></i>
                Сценарий
              </h4>
              <span className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest animate-pulse">Live</span>
            </div>
            <p className="text-xs text-slate-500 font-medium truncate">{checklist.title}</p>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            <section className="flex-1">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Диалог в реальном времени</p>
              <div className="space-y-4">
                {transcription.length === 0 && (
                  <div className="bg-slate-100/50 rounded-2xl p-8 border border-dashed border-slate-200 text-center">
                    <p className="text-[11px] text-slate-400 italic">Начните говорить...</p>
                  </div>
                )}
                {transcription.slice(-8).map((line, i) => (
                  <div key={i} className={`flex flex-col ${line.speaker === 'agent' ? 'items-end' : 'items-start'}`}>
                    <span className="text-[9px] font-bold text-slate-400 mb-1 px-1">
                      {line.speaker === 'agent' ? 'AI АГЕНТ' : 'КЛИЕНТ'}
                    </span>
                    <div className={`max-w-[90%] rounded-2xl px-4 py-2.5 text-xs shadow-sm transition-all duration-300 animate-in fade-in slide-in-from-bottom-2 ${
                      line.speaker === 'agent' 
                        ? 'bg-indigo-600 text-white rounded-tr-none' 
                        : 'bg-white text-slate-700 rounded-tl-none border border-slate-200'
                    }`}>
                      {line.text}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <div className="p-4 bg-white border-t border-slate-200">
             <p className="text-[10px] text-slate-400 text-center italic">Агент анализирует ваши эмоции в реальном времени</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ActiveCall;
