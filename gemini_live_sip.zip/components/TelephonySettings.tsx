
import React, { useState, useEffect } from 'react';
import { PhoneContact, SipConfig } from '../types';
import SipClient from '../utils/sip-client';

interface TelephonySettingsProps {
  contacts: PhoneContact[];
  setContacts: React.Dispatch<React.SetStateAction<PhoneContact[]>>;
}

const TelephonySettings: React.FC<TelephonySettingsProps> = ({ contacts, setContacts }) => {
  const [sipStatus, setSipStatus] = useState<'online' | 'offline' | 'connecting' | 'error'>('offline');
  const [newName, setNewName] = useState('');
  const [newNumber, setNewNumber] = useState('');
  const [logs, setLogs] = useState<{time: string, level: string, msg: string}[]>([]);
  
  const [sipConfig, setSipConfig] = useState<SipConfig>({
    // Connect to Local FreeSWITCH Gateway
    wsUrl: 'wss://localhost:7443', // Secure WebSocket of local FreeSWITCH
    domain: 'localhost',           // Local domain
    username: '1000',              // Local user we created
    password: 'Vflfufcrfh33',              // Local password
    displayName: 'Browser Agent'
  });

  const [activeCall, setActiveCall] = useState<{number: string, status: string} | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);

  useEffect(() => {
    const client = SipClient.getInstance();
    // Check if already connected
    if (client.isConnected()) {
        setSipStatus('online');
    }
    
    client.setStatusCallback((status) => {
        if (status === 'connected' || status === 'registered') setSipStatus('online');
        else if (status === 'disconnected') setSipStatus('offline');
        else if (status === 'connecting') setSipStatus('connecting');
        else setSipStatus('error');
    });

    client.setLogCallback((level, msg) => {
        setLogs(prev => [{
            time: new Date().toLocaleTimeString(),
            level,
            msg
        }, ...prev].slice(0, 50)); // Keep last 50 logs
    });
  }, []);

  // Audio element ref to play remote stream
  const audioRef = React.useRef<HTMLAudioElement>(null);

  useEffect(() => {
    if (audioRef.current && remoteStream) {
        audioRef.current.srcObject = remoteStream;
        audioRef.current.play().catch(e => console.error("Audio play failed", e));
    }
  }, [remoteStream]);

  const handleConnect = async () => {
    if (sipStatus === 'online') {
        await SipClient.getInstance().disconnect();
    } else {
        await SipClient.getInstance().connect(sipConfig);
    }
  };

  const handleCall = async (number: string) => {
      try {
          setActiveCall({ number, status: 'calling' });
          const localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          const stream = await SipClient.getInstance().call(number, localStream);
          setRemoteStream(stream);
          setActiveCall({ number, status: 'connected' });
      } catch (e: any) {
          console.error("Call failed", e);
          setActiveCall(null);
          alert(`Ошибка звонка: ${e.message}`);
      }
  };

  const handleHangup = () => {
      SipClient.getInstance().hangup();
      setActiveCall(null);
      setRemoteStream(null);
  };

  const addContact = () => {
    if (!newName || !newNumber) return;
    setContacts([...contacts, { id: Date.now().toString(), name: newName, number: newNumber }]);
    setNewName('');
    setNewNumber('');
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-800">Телефония и SIP</h2>
        <p className="text-slate-500 mt-1">Подключение к АТС и управление списком обзвона.</p>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm">
        <h3 className="font-bold text-lg mb-6 flex items-center gap-2">
          <i className="fas fa-server text-indigo-500"></i>
          Настройки SIP Транка
        </h3>
        <div className="flex flex-col md:flex-row gap-8 items-start">
          <div className="flex-1 space-y-4 w-full">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase mb-1 block">WebSocket URL (WSS)</label>
                <input 
                    className="w-full p-2 bg-slate-50 border rounded-lg text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none" 
                    value={sipConfig.wsUrl}
                    onChange={e => setSipConfig({...sipConfig, wsUrl: e.target.value})}
                    placeholder="wss://sip.example.com:8089/ws"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase mb-1 block">SIP Домен</label>
                <input 
                    className="w-full p-2 bg-slate-50 border rounded-lg text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none" 
                    value={sipConfig.domain}
                    onChange={e => setSipConfig({...sipConfig, domain: e.target.value})}
                    placeholder="sip.example.com"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase mb-1 block">Пользователь (Extension)</label>
                <input 
                    className="w-full p-2 bg-slate-50 border rounded-lg text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none" 
                    value={sipConfig.username}
                    onChange={e => setSipConfig({...sipConfig, username: e.target.value})}
                    placeholder="1001"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-400 uppercase mb-1 block">Пароль</label>
                <input 
                    type="password"
                    className="w-full p-2 bg-slate-50 border rounded-lg text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none" 
                    value={sipConfig.password || ''}
                    onChange={e => setSipConfig({...sipConfig, password: e.target.value})}
                    placeholder="••••••••"
                />
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-4">
              <div className={`px-4 py-2 rounded-full text-sm font-bold flex items-center gap-2 transition-colors ${
                sipStatus === 'online' ? 'bg-emerald-50 text-emerald-600' : 
                sipStatus === 'connecting' ? 'bg-amber-50 text-amber-600' :
                'bg-slate-100 text-slate-500'
              }`}>
                <span className={`w-2 h-2 rounded-full ${
                    sipStatus === 'online' ? 'bg-emerald-500' : 
                    sipStatus === 'connecting' ? 'bg-amber-500 animate-pulse' :
                    'bg-slate-400'
                }`}></span>
                {sipStatus === 'online' ? 'Соединение активно' : 
                 sipStatus === 'connecting' ? 'Подключение...' : 
                 'Отключено'}
              </div>
              
              <button 
                onClick={handleConnect}
                className={`px-6 py-2 rounded-lg text-sm font-bold text-white transition-all ${
                    sipStatus === 'online' 
                    ? 'bg-red-500 hover:bg-red-600 shadow-red-500/30' 
                    : 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-500/30'
                } shadow-lg`}
              >
                {sipStatus === 'online' ? 'Отключить' : 'Подключить SIP'}
              </button>
            </div>
            
            {sipStatus === 'error' && (
                <div className="mt-4 p-3 bg-red-50 border border-red-100 rounded-lg text-xs text-red-600">
                    <p className="font-bold mb-1"><i className="fas fa-exclamation-triangle"></i> Ошибка подключения (Code 1006)</p>
                    <p className="mb-2">Браузер заблокировал соединение. Вероятно, используется самоподписанный сертификат.</p>
                    <a 
                        href={sipConfig.wsUrl.replace('wss://', 'https://')} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="underline font-bold hover:text-red-800"
                    >
                        Нажмите сюда, откройте в новой вкладке и примите сертификат ("Advanced" -&gt; "Proceed")
                    </a>
                    <p className="mt-1">После этого попробуйте подключиться снова.</p>
                </div>
            )}
          </div>
          
          <div className="w-full md:w-64 bg-slate-50 rounded-xl p-4 text-sm text-slate-600 italic border border-slate-100">
            <div className="mb-2 font-bold text-slate-700 not-italic">Инструкция:</div>
            Для работы SIP в браузере необходим WebSocket (WSS) шлюз. Убедитесь, что ваш SIP сервер поддерживает WebRTC и WSS.
            <br/><br/>
            <strong>Кодеки:</strong> Система автоматически настроена на приоритетное использование G.711 (PCMA/PCMU), как указано в требованиях.
            <br/><br/>
            Аудиопоток будет перенаправлен в Gemini Live API для обработки.
          </div>
        </div>

        {/* Technical Info for Admin */}
        <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-6">
            <h4 className="font-bold text-indigo-900 mb-2 flex items-center gap-2">
                <i className="fas fa-info-circle"></i>
                Информация для системного администратора
            </h4>
            <p className="text-sm text-indigo-800 mb-4">
                Передайте эти параметры вашему администратору АТС для корректной настройки подключения:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
                <div className="bg-white p-4 rounded-lg border border-indigo-100 shadow-sm">
                    <strong className="block text-slate-700 mb-2 border-b pb-1">Тип клиента</strong>
                    <ul className="space-y-1 text-slate-600">
                        <li>• <strong>Библиотека:</strong> SIP.js (v0.21+)</li>
                        <li>• <strong>Технология:</strong> WebRTC</li>
                        <li>• <strong>Среда:</strong> Браузер (Chrome/Safari)</li>
                    </ul>
                </div>
                <div className="bg-white p-4 rounded-lg border border-indigo-100 shadow-sm">
                    <strong className="block text-slate-700 mb-2 border-b pb-1">Требования к транспорту</strong>
                    <ul className="space-y-1 text-slate-600">
                        <li>• <strong>Протокол:</strong> Только WSS (Secure WebSocket).</li>
                        <li>• <strong className="text-red-600">Важно:</strong> Браузеры НЕ поддерживают SIP UDP/TCP (порт 5060). Прямое подключение к UDP невозможно.</li>
                        <li>• <strong>Сертификат:</strong> Обязателен валидный SSL для WSS.</li>
                    </ul>
                </div>
                <div className="bg-white p-4 rounded-lg border border-indigo-100 shadow-sm">
                    <strong className="block text-slate-700 mb-2 border-b pb-1">Медиа (WebRTC)</strong>
                    <ul className="space-y-1 text-slate-600">
                        <li>• <strong>Аудио:</strong> Обязательно SRTP (DTLS). Обычный RTP не заработает.</li>
                        <li>• <strong>ICE:</strong> Сервер должен поддерживать ICE/STUN.</li>
                        <li>• <strong>Кодеки:</strong> G.711 (alaw/ulaw) или Opus.</li>
                    </ul>
                </div>
                <div className="bg-white p-4 rounded-lg border border-indigo-100 shadow-sm">
                    <strong className="block text-slate-700 mb-2 border-b pb-1">Что нужно сделать админу?</strong>
                    <ul className="space-y-1 text-indigo-700 font-medium">
                        <li>1. Включить <strong>WebRTC Support</strong> на АТС.</li>
                        <li>2. Открыть порт для <strong>WSS</strong> (например, 8089).</li>
                        <li>3. Установить <strong>SSL сертификат</strong>.</li>
                    </ul>
                </div>
            </div>
        </div>

        {/* Debug Logs */}
        <div className="mt-8 bg-slate-900 rounded-xl p-4 font-mono text-xs text-slate-300 h-48 overflow-y-auto">
            <div className="flex justify-between items-center mb-2 border-b border-slate-700 pb-2">
                <span className="font-bold text-slate-100">SIP Debug Logs</span>
                <button onClick={() => setLogs([])} className="text-slate-500 hover:text-white">Clear</button>
            </div>
            <div className="space-y-1">
                {logs.length === 0 && <span className="text-slate-600 italic">No logs yet...</span>}
                {logs.map((log, i) => (
                    <div key={i} className="flex gap-2">
                        <span className="text-slate-500">[{log.time}]</span>
                        <span className={`font-bold ${
                            log.level === 'error' ? 'text-red-400' : 
                            log.level === 'warn' ? 'text-amber-400' : 
                            log.level === 'success' ? 'text-emerald-400' : 
                            'text-blue-400'
                        }`}>{log.level.toUpperCase()}:</span>
                        <span>{log.msg}</span>
                    </div>
                ))}
            </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <h3 className="font-bold text-lg">Список контактов для обзвона</h3>
          <div className="flex gap-2">
            <input 
              placeholder="Имя" 
              className="text-sm p-2 border rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
              value={newName}
              onChange={e => setNewName(e.target.value)}
            />
            <input 
              placeholder="Номер" 
              className="text-sm p-2 border rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500"
              value={newNumber}
              onChange={e => setNewNumber(e.target.value)}
            />
            <button 
              onClick={addContact}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm font-medium"
            >
              Добавить
            </button>
          </div>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-xs font-bold text-slate-400 uppercase">
            <tr>
              <th className="px-6 py-4">Имя</th>
              <th className="px-6 py-4">Номер телефона</th>
              <th className="px-6 py-4">Последний звонок</th>
              <th className="px-6 py-4 text-right">Действия</th>
            </tr>
          </thead>
          <tbody className="text-sm divide-y divide-slate-100">
            {contacts.map(c => (
              <tr key={c.id} className="hover:bg-slate-50">
                <td className="px-6 py-4 font-medium text-slate-700">{c.name}</td>
                <td className="px-6 py-4 text-slate-600 font-mono">{c.number}</td>
                <td className="px-6 py-4 text-slate-400">---</td>
                <td className="px-6 py-4 text-right flex justify-end gap-2">
                  {activeCall?.number === c.number ? (
                      <button 
                        onClick={handleHangup}
                        className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded-md text-xs font-bold flex items-center gap-1 animate-pulse"
                      >
                        <i className="fas fa-phone-slash"></i> Сбросить
                      </button>
                  ) : (
                      <button 
                        onClick={() => handleCall(c.number)}
                        disabled={sipStatus !== 'online' || activeCall !== null}
                        className={`px-3 py-1 rounded-md text-xs font-bold flex items-center gap-1 ${
                            sipStatus === 'online' && activeCall === null
                            ? 'bg-emerald-500 hover:bg-emerald-600 text-white' 
                            : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                        }`}
                      >
                        <i className="fas fa-phone"></i> Позвонить
                      </button>
                  )}
                  
                  <button onClick={() => setContacts(contacts.filter(x => x.id !== c.id))} className="text-red-400 hover:text-red-600 px-2">
                    <i className="fas fa-trash"></i>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {/* Hidden audio element for remote stream */}
        <audio ref={audioRef} autoPlay style={{ display: 'none' }} />
      </div>
    </div>
  );
};

export default TelephonySettings;
