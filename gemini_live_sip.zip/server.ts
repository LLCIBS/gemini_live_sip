import express from 'express';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dgram from 'dgram';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Configuration for the legacy SIP server
const SIP_TARGET = {
  host: '176.67.241.251',
  port: 5060
};

async function startServer() {
  const app = express();
  const server = createServer(app);
  const PORT = 3000;

  // Create WebSocket Server but don't bind it to a port yet
  const wss = new WebSocketServer({ noServer: true });

  // UDP Socket for communicating with the legacy SIP server
  const udpSocket = dgram.createSocket('udp4');

  udpSocket.on('error', (err) => {
    console.error(`UDP Socket error:\n${err.stack}`);
    udpSocket.close();
  });

  udpSocket.on('message', (msg, rinfo) => {
    // Forward UDP packet from SIP Server -> WebSocket Client
    wss.clients.forEach((client) => {
      if (client.readyState === 1) { // WebSocket.OPEN
        client.send(msg.toString());
      }
    });
  });

  udpSocket.bind(() => {
    console.log(`UDP Proxy listening for SIP responses`);
  });

  // WebSocket connection handling
  wss.on('connection', (ws) => {
    console.log('WS Client connected (SIP Proxy)');
    
    ws.on('message', (message) => {
      // Forward WebSocket message -> SIP Server (UDP)
      const buffer = Buffer.from(message.toString());
      udpSocket.send(buffer, SIP_TARGET.port, SIP_TARGET.host, (err) => {
        if (err) {
          console.error('UDP send error:', err);
        }
      });
    });
  });

  // Handle upgrade manually to share port 3000 with Express
  server.on('upgrade', (request, socket, head) => {
    // Only handle upgrades for SIP proxy, let Vite handle HMR if needed (though HMR is disabled here)
    // In this environment, we just accept all WS connections on the main port
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  });

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', mode: 'server', proxyTarget: SIP_TARGET });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false }, // Disable HMR to avoid WS conflicts
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`SIP Proxy active: WSS <-> UDP://${SIP_TARGET.host}:${SIP_TARGET.port}`);
  });
}

startServer();
