import { WebSocketServer } from 'ws';
import dgram from 'dgram';
import os from 'os';

// Configuration
const CONFIG = {
  WS_PORT: 8080,
  SIP_HOST: '176.67.241.251',
  SIP_PORT: 5060,
  UDP_PORT: 0 // Random local port
};

// Helper to get Local IP
function getLocalIp() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        return net.address;
      }
    }
  }
  return '127.0.0.1';
}

const LOCAL_IP = getLocalIp();

console.log('=== SMART SIP PROXY STARTED ===');
console.log(`Target SIP Server: ${CONFIG.SIP_HOST}:${CONFIG.SIP_PORT}`);
console.log(`Local IP detected: ${LOCAL_IP}`);

const udpSocket = dgram.createSocket('udp4');
const wss = new WebSocketServer({ port: CONFIG.WS_PORT });
const clients = new Set();
const transactions = new Map(); // branch -> originalVia

let PROXY_PORT = 0;

// --- UDP Handling (From SIP Server) ---

udpSocket.on('error', (err) => {
  console.error(`[UDP ERROR] ${err.stack}`);
  udpSocket.close();
});

udpSocket.on('message', (msg, rinfo) => {
  let packet = msg.toString();
  console.log(`\n[UDP <- SIP Server] Received ${msg.length} bytes from ${rinfo.address}:${rinfo.port}`);
  
  // --- REVERSE HEADER MANIPULATION (UDP -> WS) ---
  
  // 1. Extract branch to find original Via
  const branchMatch = packet.match(/;branch=([^;]+)/);
  let restored = false;

  if (branchMatch) {
      const branch = branchMatch[1];
      if (transactions.has(branch)) {
          const originalVia = transactions.get(branch);
          
          // Replace the Via header from PBX with the Original Via from Browser
          // We replace the FIRST Via header we find. Added 'm' flag for multiline matching.
          packet = packet.replace(/^Via: .+\r\n/im, `${originalVia}\r\n`);
          
          console.log(`[Proxy] Restored original Via for branch ${branch}`);
          restored = true;
      }
  } 
  
  if (!restored) {
      // Fallback: Just change protocol if we couldn't find the transaction
      packet = packet.replace(/SIP\/2\.0\/UDP/g, 'SIP/2.0/WS');
  }

  console.log('--- REWRITTEN RESPONSE (Sent to Browser) ---');
  console.log(packet);
  console.log('------------------------------------------');
  
  for (const client of clients) {
    if (client.readyState === 1) {
      client.send(packet);
      console.log(`[Proxy -> WS Client] Forwarded response`);
    }
  }
});

udpSocket.on('listening', () => {
  const address = udpSocket.address();
  PROXY_PORT = address.port;
  console.log(`[UDP] Proxy listening on ${LOCAL_IP}:${PROXY_PORT}`);
  console.log(`[WS] WebSocket listening on ws://localhost:${CONFIG.WS_PORT}`);
});

udpSocket.bind(CONFIG.UDP_PORT);

// --- WebSocket Handling (From Browser) ---

wss.on('connection', (ws, req) => {
  console.log(`\n[WS] Client connected`);
  clients.add(ws);

  ws.on('message', (message) => {
    let packet = message.toString();
    console.log(`\n[WS -> Proxy] Received ${packet.length} bytes`);
    
    // --- SIP HEADER MANIPULATION ---
    
    // 1. Capture Original Via and Branch
    // Matches the first Via line
    const viaMatch = packet.match(/^(Via: .+\r\n)/m);
    // Fix: Stop at semicolon OR newline to avoid capturing subsequent headers
    const branchMatch = packet.match(/;branch=([^;\r\n]+)/);
    
    if (viaMatch && branchMatch) {
        const originalVia = viaMatch[1].trim(); // Remove newline
        const branch = branchMatch[1];
        transactions.set(branch, originalVia);
        console.log(`[Proxy] Stored transaction branch: ${branch}`);
        
        // Cleanup old transactions periodically or just let them grow (for dev tool it's fine)
        if (transactions.size > 1000) transactions.clear();
    }

    // 2. Replace Transport
    packet = packet.replace(/SIP\/2\.0\/WS/g, 'SIP/2.0/UDP');
    packet = packet.replace(/transport=ws/g, 'transport=udp');
    
    // 3. Replace Via host with Proxy IP
    // We replace the whole Via line with our constructed one
    const viaRegex = /^Via: .+\r\n/m;
    // Note: We keep the branch ID!
    if (branchMatch) {
        packet = packet.replace(viaRegex, `Via: SIP/2.0/UDP ${LOCAL_IP}:${PROXY_PORT};rport;branch=${branchMatch[1]}\r\n`);
    } else {
        packet = packet.replace(viaRegex, `Via: SIP/2.0/UDP ${LOCAL_IP}:${PROXY_PORT};rport\r\n`);
    }
    
    // 4. Replace Contact host
    const contactRegex = /Contact: <sip:([^@]+)@([^>;]+)/;
    packet = packet.replace(contactRegex, (match, user, domain) => {
        return `Contact: <sip:${user}@${LOCAL_IP}:${PROXY_PORT}`;
    });

    console.log('--- REWRITTEN PACKET (Sent to PBX) ---');
    console.log(packet);
    console.log('--------------------------------------');
    
    const buffer = Buffer.from(packet);
    
    // Send to SIP Server
    udpSocket.send(buffer, CONFIG.SIP_PORT, CONFIG.SIP_HOST, (err) => {
      if (err) {
        console.error(`[UDP SEND ERROR]`, err);
      } else {
        console.log(`[Proxy -> SIP Server] Sent to ${CONFIG.SIP_HOST}:${CONFIG.SIP_PORT}`);
      }
    });
  });

  ws.on('close', () => {
    console.log('[WS] Client disconnected');
    clients.delete(ws);
  });
});
