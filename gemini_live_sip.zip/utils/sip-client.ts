import { UserAgent, Inviter, SessionState, UserAgentOptions, Registerer, Invitation, RegistererState } from 'sip.js';
import { SipConfig } from '../types';

// Standalone modifier function to force G.711
const g711Modifier = (description: RTCSessionDescriptionInit): Promise<RTCSessionDescriptionInit> => {
  if (!description.sdp) return Promise.resolve(description);
  
  console.log("Original SDP:", description.sdp);

  const lines = description.sdp.split(/\r\n|\r|\n/);
  const newLines: string[] = [];
  
  for (const line of lines) {
    if (line.startsWith('m=audio')) {
      const parts = line.split(' ');
      // m=audio <port> <proto> <fmt> ...
      if (parts.length > 3) {
        // Keep only PCMA (8) and PCMU (0)
        // We also keep telephone-event (usually 101, but can be others) and CN (13)
        // We will filter based on the rtpmap later, but for the m-line we need to be careful.
        // Strategy: Keep 0, 8, 13. For others, we need to check if they are telephone-event.
        // Since we can't easily check rtpmap while parsing the m-line, we will keep ALL dynamic payloads (96-127) for now,
        // and then filter them out in the rtpmap pass if they are NOT telephone-event.
        
        const allPayloads = parts.slice(3);
        const keptPayloads = allPayloads.filter(p => {
          const pt = parseInt(p, 10);
          return p === '0' || p === '8' || p === '13' || (pt >= 96 && pt <= 127);
        });
        
        // Force PCMA (8) to be first
        keptPayloads.sort((a, b) => {
          if (a === '8') return -1;
          if (b === '8') return 1;
          return 0;
        });

        // Rewrite m-line
        const newLine = `${parts[0]} ${parts[1]} ${parts[2]} ${keptPayloads.join(' ')}`;
        newLines.push(newLine);
        continue;
      }
    }
    
    // Filter out rtpmap and fmtp for removed payloads
    if (line.startsWith('a=rtpmap:') || line.startsWith('a=fmtp:')) {
      const payloadMatch = line.match(/:(\d+)/);
      if (payloadMatch) {
        const payload = payloadMatch[1];
        const pt = parseInt(payload, 10);
        
        // Always keep 0, 8, 13
        if (payload === '0' || payload === '8' || payload === '13') {
          newLines.push(line);
          continue;
        }
        
        // For dynamic payloads (96-127), check if it is telephone-event
        if (pt >= 96 && pt <= 127) {
          if (line.includes('telephone-event')) {
             newLines.push(line); // Keep telephone-event
             continue;
          }
          // If it's fmtp, we need to know if the corresponding rtpmap was kept.
          // This is tricky in a single pass. 
          // But usually fmtp comes after rtpmap.
          // Let's assume if we kept the payload in m-line, we might keep it here, 
          // BUT we specifically want to REMOVE Opus (111).
          
          if (line.includes('opus')) {
            continue; // Explicitly remove Opus
          }
          
          // If we are unsure, maybe keep it? 
          // But better to be safe and remove if not explicitly allowed.
          // Let's rely on the fact that we want G.711.
          
          // If it is NOT telephone-event and NOT G.711, remove it.
          // So if it's Opus, VP8, H264, etc., remove it.
          if (!line.includes('telephone-event')) {
            continue;
          }
           newLines.push(line);
           continue;
        }
        
        // Remove others (like G.722 which is 9)
        continue;
      }
    }
    
    newLines.push(line);
  }

  const newSdp = newLines.join('\r\n');
  console.log("Modified SDP (G.711 only):", newSdp);
  
  description.sdp = newSdp;
  return Promise.resolve(description);
};

class SipClient {
  private static instance: SipClient;
  private userAgent: UserAgent | null = null;
  private registerer: Registerer | null = null;
  private currentSession: Inviter | Invitation | null = null;
  private config: SipConfig | null = null;
  private onStatusChange: ((status: string) => void) | null = null;
  private onIncomingCall: ((session: Invitation) => void) | null = null;
  private onLog: ((level: string, message: string) => void) | null = null;

  private constructor() {}

  public static getInstance(): SipClient {
    if (!SipClient.instance) {
      SipClient.instance = new SipClient();
    }
    return SipClient.instance;
  }

  public setStatusCallback(callback: (status: string) => void) {
    this.onStatusChange = callback;
  }

  public setIncomingCallCallback(callback: (session: Invitation) => void) {
    this.onIncomingCall = callback;
  }

  public setLogCallback(callback: (level: string, message: string) => void) {
    this.onLog = callback;
  }

  private log(level: string, message: string) {
    if (this.onLog) {
      this.onLog(level, message);
    }
    console.log(`[SIP ${level}] ${message}`);
  }

  public async connect(config: SipConfig) {
    if (this.userAgent) {
      await this.disconnect();
    }

    this.config = config;
    const uri = UserAgent.makeURI(`sip:${config.username}@${config.domain}`);
    if (!uri) {
      this.log('error', 'Invalid SIP URI constructed');
      throw new Error('Invalid SIP URI');
    }

    this.log('info', `Connecting to ${config.wsUrl} as ${uri.toString()}`);

    const options: UserAgentOptions = {
      uri,
      transportOptions: {
        server: config.wsUrl,
      },
      authorizationUsername: config.username,
      authorizationPassword: config.password,
      displayName: config.displayName || config.username,
      sessionDescriptionHandlerFactoryOptions: {
        modifiers: [g711Modifier]
      },
      logConnector: (level, content) => {
        this.log(level, content);
      },
      delegate: {
        onConnect: () => {
          this.log('success', 'WebSocket Connected');
          this.onStatusChange?.('connected');
          this.register();
        },
        onDisconnect: (error) => {
          this.log('warn', `WebSocket Disconnected: ${error || 'Unknown reason'}`);
          this.onStatusChange?.('disconnected');
          if (error) console.error('SIP Disconnected with error:', error);
        },
        onInvite: (invitation) => {
          this.log('info', 'Incoming call received');
          this.handleIncomingCall(invitation);
        }
      }
    };

    try {
      this.userAgent = new UserAgent(options);
      this.onStatusChange?.('connecting'); // Set status BEFORE starting
      await this.userAgent.start();
    } catch (e: any) {
      this.log('error', `Failed to start UserAgent: ${e.message}`);
      this.onStatusChange?.('error');
    }
  }

  private async register() {
    if (!this.userAgent) return;
    this.log('info', 'Attempting to register...');
    this.registerer = new Registerer(this.userAgent);
    
    // Listen for state changes to confirm registration
    this.registerer.stateChange.addListener((newState) => {
      switch (newState) {
        case RegistererState.Registered:
          this.log('success', 'Registration Confirmed (200 OK)');
          this.onStatusChange?.('registered');
          break;
        case RegistererState.Unregistered:
          this.log('info', 'Unregistered');
          this.onStatusChange?.('unregistered');
          break;
        case RegistererState.Terminated:
          // this.log('warn', 'Registration Terminated');
          break;
      }
    });

    try {
      await this.registerer.register();
      this.log('info', 'Register request sent');
    } catch (e: any) {
      this.log('error', `Registration failed: ${e.message || e}`);
      console.error('Registration failed', e);
      this.onStatusChange?.('registration_failed');
    }
  }

  public async disconnect() {
    if (this.registerer) {
      await this.registerer.unregister();
      this.registerer = null;
    }
    if (this.userAgent) {
      await this.userAgent.stop();
      this.userAgent = null;
    }
    this.onStatusChange?.('disconnected');
  }

  public async call(target: string, localStream: MediaStream): Promise<MediaStream> {
    if (!this.userAgent || !this.config) throw new Error('SIP Client not connected');
    
    const targetUri = UserAgent.makeURI(`sip:${target}@${this.config.domain}`);
    if (!targetUri) throw new Error('Invalid target URI');

    const inviter = new Inviter(this.userAgent, targetUri);

    this.currentSession = inviter;

    return new Promise((resolve, reject) => {
      inviter.stateChange.addListener((newState) => {
        console.log(`Session state changed to ${newState}`);
        if (newState === SessionState.Established) {
           const remoteStream = new MediaStream();
           inviter.sessionDescriptionHandler?.peerConnection?.getReceivers().forEach((receiver) => {
             if (receiver.track) {
               remoteStream.addTrack(receiver.track);
             }
           });
           resolve(remoteStream);
        } else if (newState === SessionState.Terminated) {
           // reject(new Error('Call terminated'));
        }
      });

      inviter.invite({
        sessionDescriptionHandlerOptions: {
          constraints: { audio: true, video: false },
          localStream,
          modifiers: [g711Modifier]
        },
        sessionDescriptionHandlerModifiers: [g711Modifier]
      })
      .catch((error) => {
        console.error('Invite failed', error);
        reject(error);
      });
    });
  }

  public async answer(invitation: Invitation, localStream: MediaStream): Promise<MediaStream> {
    this.currentSession = invitation;
    return new Promise((resolve, reject) => {
      invitation.stateChange.addListener((newState) => {
        if (newState === SessionState.Established) {
           const remoteStream = new MediaStream();
           invitation.sessionDescriptionHandler?.peerConnection?.getReceivers().forEach((receiver) => {
             if (receiver.track) {
               remoteStream.addTrack(receiver.track);
             }
           });
           resolve(remoteStream);
        }
      });

      invitation.accept({
        sessionDescriptionHandlerOptions: {
          constraints: { audio: true, video: false },
          localStream,
          modifiers: [g711Modifier] // Apply modifier HERE
        }
      }).catch(reject);
    });
  }

  public hangup() {
    if (this.currentSession) {
      switch (this.currentSession.state) {
        case SessionState.Initial:
        case SessionState.Establishing:
          if (this.currentSession instanceof Inviter) {
            this.currentSession.cancel();
          } else {
            this.currentSession.reject();
          }
          break;
        case SessionState.Established:
          this.currentSession.bye();
          break;
      }
      this.currentSession = null;
    }
  }

  private handleIncomingCall(invitation: Invitation) {
    if (this.onIncomingCall) {
      this.onIncomingCall(invitation);
    } else {
      invitation.reject();
    }
  }
  
  public isConnected(): boolean {
      return !!this.userAgent && this.userAgent.state === 'Started'; // Simplified check
  }
}

export default SipClient;
